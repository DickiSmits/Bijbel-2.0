# BIJBELREADER - COMPLETE PROJECT DOCUMENTATIE

**Voor toekomstige Claude sessies: Upload dit bestand!**

---

## 📋 PROJECT OVERZICHT

**Type:** Bijbelreader met annotaties en opmaak systeem
**Tech Stack:** PHP (MVC), SQLite, JavaScript, Bootstrap 5, Leaflet, Vis-Timeline, Quill
**Database:** NWT-Bijbel.db (SQLite)

---

## 🏗️ ARCHITECTUUR

### MVC Structuur
```
/
├── index.php                 # Router + main entry
├── config.php                # Database config
├── /api/                     # API endpoints (JSON)
│   ├── verses.php
│   ├── chapter_profiles.php  # Multi-profiel mappings
│   ├── books.php
│   ├── chapters.php
│   ├── save_formatting.php
│   └── ...
├── /views/                   # View templates
│   ├── reader.php            # Lees modus
│   ├── admin.php             # Admin modus
│   └── login.php
├── /assets/
│   ├── /css/style.css        # Custom CSS + multi-profiel tooltips
│   └── /js/
│       ├── app.js
│       ├── reader.js         # Reader logica
│       ├── admin.js
│       ├── map.js            # Leaflet kaart
│       └── timeline.js       # Vis-timeline
└── /images/                  # Geüploade afbeeldingen
```

### Database Schema (SQLite)

```sql
-- CORE TABLES (READ-ONLY)
De_Bijbel (
    Vers_ID INTEGER PRIMARY KEY,
    Boeknummer INTEGER,
    Bijbelboeknaam TEXT,
    Hoofdstuknummer INTEGER,
    Versnummer INTEGER,
    Tekst TEXT
)

-- OPMAAK SYSTEEM (USER DATA)
Profielen (
    Profiel_ID INTEGER PRIMARY KEY,
    Profiel_Naam TEXT,
    Beschrijving TEXT
)

Opmaak (
    Opmaak_ID INTEGER PRIMARY KEY,
    Profiel_ID INTEGER,
    Vers_ID INTEGER,
    Opgemaakte_Tekst TEXT,  -- HTML from Quill editor
    Laatst_Gewijzigd DATETIME,
    FOREIGN KEY (Profiel_ID) REFERENCES Profielen(Profiel_ID),
    FOREIGN KEY (Vers_ID) REFERENCES De_Bijbel(Vers_ID)
)

-- TIMELINE SYSTEEM
Timeline_Groups (
    Group_ID INTEGER PRIMARY KEY,
    Groep_Naam TEXT,
    Kleur TEXT,
    Zichtbaar INTEGER DEFAULT 1,
    Volgorde INTEGER
)

Timeline_Events (
    Event_ID INTEGER PRIMARY KEY,
    Titel TEXT,
    Beschrijving TEXT,  -- HTML from Quill
    Start_Datum TEXT,   -- "2024-01-15" or "-1000"
    End_Datum TEXT,
    Vers_ID_Start INTEGER,
    Vers_ID_End INTEGER,
    Type TEXT,          -- "point" or "range"
    Kleur TEXT,
    Tekst_Kleur TEXT,
    Group_ID INTEGER,
    FOREIGN KEY (Vers_ID_Start) REFERENCES De_Bijbel(Vers_ID),
    FOREIGN KEY (Group_ID) REFERENCES Timeline_Groups(Group_ID)
)

-- LOCATIES
Locaties (
    Locatie_ID INTEGER PRIMARY KEY,
    Naam TEXT,
    Latitude REAL,
    Longitude REAL,
    Type TEXT,
    Beschrijving TEXT
)

Vers_Locaties (
    Vers_ID INTEGER,
    Locatie_ID INTEGER,
    Context TEXT,
    PRIMARY KEY (Vers_ID, Locatie_ID)
)

-- AFBEELDINGEN
Afbeeldingen (
    Afbeelding_ID INTEGER PRIMARY KEY,
    Bestandsnaam TEXT,
    Bestandspad TEXT,
    Vers_ID INTEGER,
    Caption TEXT,
    Uitlijning TEXT,  -- "left", "center", "right"
    Breedte INTEGER,
    Hoogte INTEGER
)

-- NOTITIES
Notities (
    Notitie_ID INTEGER PRIMARY KEY,
    Titel TEXT,
    Inhoud TEXT,  -- HTML from Quill
    Aangemaakt DATETIME,
    Gewijzigd DATETIME
)
```

---

## 🎨 KEY FEATURES

### 1. Multi-Profiel Opmaak Systeem
- **Gebruikers kunnen meerdere profielen maken** (bijv. "Studieversie", "Kinderversie")
- **Quill editor** voor rijke tekstopmaak (bold, italic, kleuren, fonts)
- **Originele tekst blijft intact** - wijzigingen in Opmaak tabel
- **Per-vers of per-hoofdstuk bewerken**

### 2. Multi-Profiel Indicator (V3)
- **Lichtblauwe versnummers** (#4A90E2) als vers bewerkt is in andere profielen
- **Instant tooltip** (0ms delay) toont profielnamen
- **MutationObserver** auto-detecteert nieuwe hoofdstukken bij infinite scroll
- **Smart caching** voorkomt duplicate API calls

**Implementatie:**
- JavaScript in `index.php` (inline script, reader mode only)
- CSS in `/assets/css/style.css`
- API: `/api/chapter_profiles.php`

**Voorbeeld:**
```
Vers 1: "In het begin..." ← BLAUW
[Hover: "Bewerkt in: Studieversie, Kinderversie"]
```

### 3. Timeline Systeem
- **Vis-Timeline** voor historische events
- **Groepen** voor categorieën (bijv. "Personen", "Gebeurtenissen")
- **Koppeling aan verzen** (Vers_ID_Start, Vers_ID_End)
- **Kleuren per event** + custom tekstkleur
- **Zichtbaarheid toggle** per groep

### 4. Kaart (Leaflet)
- **OpenStreetMap** basis
- **Locatie markers** met custom icons
- **Koppeling aan verzen**
- **Auto-detectie** locaties in verstekst

### 5. Infinite Scroll
- **Lazy loading** 50 verzen per keer
- **Onbeperkt scrollen** door alle 66 boeken
- **Bidirectioneel** (vooruit + achteruit)
- **Chapter headers** sticky positioning

---

## 🔑 KRITIEKE DESIGN PATTERNS

### BELANGRIJK: De_Bijbel Tabel is READ-ONLY!
```php
/*
 * NOOIT De_Bijbel bewerken!
 * Alle wijzigingen in Opmaak tabel.
 * Originele tekst blijft intact.
 */
```

### Opmaak Opslaan Flow
```
Admin selecteert vers
    ↓
Quill editor toont originele tekst
    ↓
Gebruiker bewerkt (bold, italic, etc)
    ↓
Opslaan → INSERT/UPDATE Opmaak tabel
    ↓
Reader toont: Opgemaakte_Tekst ?? Tekst
```

### Multi-Profiel Indicator Flow
```
Reader laadt verzen
    ↓
MutationObserver detecteert .chapter-header
    ↓
Parse: "Genesis 1" → boek="Genesis", hoofdstuk="1"
    ↓
API call: chapter_profiles.php?boek=Genesis&hoofdstuk=1
    ↓
Response: {1: [{Profiel_ID: 1, Naam: "Studie"}], 2: [...]}
    ↓
Loop door verzen, update .verse-number:
  - Filter huidige profiel
  - Andere profielen? → Add .has-other-profiles class
  - Set data-tooltip="Studie, Kindversie"
    ↓
CSS tooltip verschijnt bij hover (0ms delay)
```

---

## 🛠️ TECHNISCHE DETAILS

### API Endpoints
```
GET ?api=verses&boek=Genesis&hoofdstuk=1&limit=50&offset=0&profiel_id=1
→ Returns: [{Vers_ID, Tekst, Opgemaakte_Tekst}, ...]

GET ?api=chapter_profiles&boek=Genesis&hoofdstuk=1
→ Returns: {
    "1": [{Profiel_ID: 1, Profiel_Naam: "Studie"}, ...],
    "2": [{Profiel_ID: 2, Profiel_Naam: "Kind"}],
    ...
}

GET ?api=books
→ Returns: [{Bijbelboeknaam, First_ID}, ...]

GET ?api=chapters&boek=Genesis
→ Returns: [{Hoofdstuknummer}, ...]

POST ?api=save_formatting
Body: {profiel_id, vers_id, tekst}
→ INSERT/UPDATE Opmaak

GET ?api=timeline&vers_id=123
→ Returns events linked to this verse

GET ?api=locations&vers_id=123
→ Returns locations linked to this verse
```

### CSS Tooltips (Instant - 0ms delay)
```css
.verse-number.has-other-profiles[data-tooltip]::after {
    content: "Bewerkt in: " attr(data-tooltip);
    position: absolute;
    bottom: calc(100% + 8px);
    background: rgba(44, 82, 130, 0.95);
    color: white;
    transition: none;  /* ← INSTANT! */
    opacity: 0;
    visibility: hidden;
}

.verse-number.has-other-profiles[data-tooltip]:hover::after {
    opacity: 1;
    visibility: visible;
}
```

### JavaScript Global Variables
```javascript
// Reader mode
let currentBook = null;
let currentChapter = null;
let currentProfile = null;
let currentVerse = null;

// Functions
apiCall(endpoint)  // Wrapper for fetch()
loadVerses(append)
selectVerse(versId)
```

---

## 🎯 COMMON TASKS

### Nieuwe Feature Toevoegen
1. **Database:** Maak tabel/kolommen in SQLite
2. **API:** Maak endpoint in `/api/feature.php`
3. **View:** Update `/views/reader.php` of `/views/admin.php`
4. **JavaScript:** Voeg logica toe in `/assets/js/`
5. **CSS:** Style in `/assets/css/style.css`

### Opmaak Probleem Debuggen
```javascript
// In console:
SELECT * FROM Opmaak WHERE Vers_ID = 123;
// Check Opgemaakte_Tekst kolom - moet HTML bevatten

// Of via API:
fetch('?api=verse_detail&vers_id=123&profiel_id=1')
  .then(r => r.json())
  .then(d => console.log(d.Opgemaakte_Tekst));
```

### Multi-Profiel Indicator Debuggen
```javascript
// In console:
multiProfielDebug.cache        // Check loaded profiles
multiProfielDebug.processed    // Check processed chapters
multiProfielDebug.scan()       // Force re-scan
multiProfielDebug.reprocess()  // Force re-process
```

---

## 🐛 KNOWN ISSUES & SOLUTIONS

### Issue: Quill toolbar buttons overlappen
**Oorzaak:** z-index conflict met Bootstrap dropdown
**Oplossing:**
```css
.ql-toolbar .ql-picker-options {
    z-index: 1000 !important;
}
```

### Issue: Tooltip heeft delay
**Oorzaak:** CSS transition of browser title attribute
**Oplossing:** Gebruik `data-tooltip` + `transition: none`

### Issue: Multi-profiel werkt niet bij eerste load
**Oorzaak:** Oude versie checkte currentBook/currentChapter
**Oplossing:** V3 met MutationObserver

### Issue: Reset button verwijdert opmaak niet uit database
**Oorzaak:** Alleen lokale Quill clear
**Oplossing:**
```javascript
// In saveFormatting():
if (quill.getText().trim() === verse.Tekst) {
    // Unchanged - delete from Opmaak
    await apiCall(`delete_formatting&vers_id=${versId}&profiel_id=${profielId}`);
}
```

---

## 📦 DEPLOYMENT CHECKLIST

- [ ] Database: NWT-Bijbel.db (SQLite) geüpload
- [ ] config.php: ADMIN_PASSWORD gewijzigd
- [ ] /images/ directory: 0755 permissions
- [ ] API endpoints: Alle .php bestanden in /api/
- [ ] CSS: Multi-profiel tooltips toegevoegd
- [ ] JavaScript: V3 auto-detect script in index.php
- [ ] Test: Infinite scroll werkt
- [ ] Test: Multi-profiel indicator werkt bij eerste load
- [ ] Test: Tooltips zijn instant (0ms)

---

## 🔗 BELANGRIJKE LINKS

**Quill Editor:** https://quilljs.com/docs/
**Vis-Timeline:** https://visjs.github.io/vis-timeline/docs/timeline/
**Leaflet:** https://leafletjs.com/reference.html
**Bootstrap 5:** https://getbootstrap.com/docs/5.3/

---

## 💡 FUTURE IDEAS

- [ ] Export naar PDF met opmaak
- [ ] Collaborative editing (meerdere gebruikers)
- [ ] Verse linking (verwijzingen naar andere verzen)
- [ ] Audio playback
- [ ] Dark mode
- [ ] Mobile app (PWA)
- [ ] Zoeken in opgemaakte tekst
- [ ] Tagging systeem
- [ ] Backup/restore functionaliteit

---

## 🎓 VOOR CLAUDE IN NIEUWE SESSIE

**Als gebruiker zegt:**
"Ik werk aan mijn Bijbelreader, hier is de documentatie"

**Dan weet je:**
1. ✅ De_Bijbel tabel is READ-ONLY
2. ✅ Opmaak in aparte tabel met Profiel_ID
3. ✅ Multi-profiel indicator met MutationObserver
4. ✅ Instant tooltips met data-tooltip attribute
5. ✅ MVC architectuur met API endpoints
6. ✅ SQLite database
7. ✅ Quill voor rich text editing

**Vraag altijd:**
- "Welke bestanden wil je dat ik bekijk?"
- "Heb je de huidige code die ik kan analyseren?"
- "Wat is de nieuwe feature/bug?"

---

**Laatste update:** 28 december 2024
**Versie:** V3 (Multi-profiel auto-detect + instant tooltips)
